# Team10- SUPERBOWL
library(textreadr)
library(dplyr)
library(stringr)
library(tidytext)
library(topicmodels)
library(tidytext)
library(ggplot2)
library(dplyr)
library(reshape2)
library(tidyr)
library(scales)
library(wordcloud)
library(igraph)
library(ggraph)
library(wordcloud2)
library(syuzhet)
library(tm)
library(quanteda)
library(quanteda.textmodels)

# Reading the doc document
doc_file_path <- read_document("C:/Users/akshayv/Desktop/Shefa/HULT/DataScience-R/TextAnalytics&NLP/Team10/team10/SuperBowltextFinal.docx")

#Define parameters and create a empty dataframe
rows <- 43 #how many observations to you have - how many people you have
cols <- 6 #how many variables do you have - how many answers per person
my_df <- as.data.frame(matrix(nrow=rows, ncol=cols))


# Creating a nested for loop to fill in dataframe with corresponding line item
for(z in 1:cols){
    for(i in 1:rows){
        my_df[i,z]<- doc_file_path[i*cols+z-cols]
    }#closing z loop
}#closing i loop

# ID creation
my_df <- my_df %>% 
    mutate(ID = seq(1:nrow(my_df)))
#View(my_df)

#Create a dataframe for each question
q1 <- data_frame(text=my_df$V1)
q2 <- data_frame(text=my_df$V2)
q3 <- data_frame(text=my_df$V3)
q4 <- data_frame(text=my_df$V4)
q5 <- data_frame(text=my_df$V5)
q6 <- data_frame(text=my_df$V6)

questions <- c("Question1", "Question2", "Question3","Question4","Question5","Question6")
colnames(my_df) <- questions
#my_df

#Creating dummies for response variable
my_df[grep('Yes',  my_df$Question6), 'Question6'] <- 1
my_df[grep('No',  my_df$Question6), 'Question6'] <- 0

#Transforming dataframe
my_df <- melt(my_df,id.vars = c('Question6'))

# Changing all column names 
colnames(my_df) <- c('response', 'questions', 'value')
#View(my_df)

############################ Bigrams ##################################
# Bigram Creation

my_df_bigram <- my_df %>%
    unnest_tokens(bigram, value, token = "ngrams", n=2)

my_df_bigram <- my_df_bigram[complete.cases(my_df_bigram), ]


#counting Bigrams
my_df_bigram %>%
    count(bigram, sort = TRUE)

# Bigram Cleaning
bigrams_separated <- my_df_bigram %>%
        separate(bigram, c("word1", "word2"), sep = " ") # split them into word1 and word2

bigrams_filtered <- bigrams_separated %>%
    filter(!word1 %in% stop_words$word) %>%
    filter(!word2 %in% stop_words$word)

# new bigram counts:
bigram_counts <- bigrams_filtered %>% 
    count(word1, word2, sort = TRUE)
#bigram_counts

bigrams_united <- bigrams_filtered %>%
    unite(bigram, word1, word2, sep = " ")
#bigrams_united

bigram_tf_idf <- bigrams_united %>%
    count(questions, bigram) %>%
    bind_tf_idf(bigram, questions, n) %>%
    arrange(desc(tf_idf))
bigram_tf_idf

bigrams_separated %>%
    filter(word1 == "no") %>%
    count(word1, word2, sort = TRUE)

#creating the new bigram, "no-stop-words" for response 0 - not productive:
bigram_counts0 <- bigrams_filtered %>%
    filter(response == "0") %>%
    count(word1, word2, sort = TRUE)

#creating the new bigram, "no-stop-words" for response 1 - not productive:
bigram_counts1 <- bigrams_filtered %>%
    filter(response == "1") %>%
    count(word1, word2, sort = TRUE)

#Visualization
#Network non-productive
bigram_graph0 <- bigram_counts0 %>%
    filter(n>0.5) %>% 
    graph_from_data_frame()

nonProductiveBigram<- ggraph(bigram_graph0, layout = "fr") +
    geom_edge_link()+
    geom_node_point()+
    geom_node_text(aes(label=name), vjust =1, hjust=1)+
    ggtitle(" Network for non-productive Respondents")
nonProductiveBigram

#Network productive
bigram_graph1 <- bigram_counts1 %>%
    filter(n>0.5) %>% 
    graph_from_data_frame()

productiveBigram<- ggraph(bigram_graph1, layout = "fr") +
    geom_edge_link()+
    geom_node_point()+
    geom_node_text(aes(label=name), vjust =1, hjust=1)+
    ggtitle(" Network for productive Respondents")

productiveBigram

full_bigram = list(productive = list(bigram_counts1, productiveBigram),
                   nonproductive = list(bigram_counts0, nonProductiveBigram))
#full_bigram

################# TFIDF ########################################
# Dataframe for this section
all_merged<- my_df %>% 
    unnest_tokens(word, value) %>%
    anti_join(stop_words) %>% 
    count(word, questions, response, sort = TRUE)

# Filter non-productive
all_merged_nonprod <- all_merged %>% 
    filter(response == 0)

# TFIDF Creation non-productive
all_merged_nonprod <- all_merged_nonprod %>%
    bind_tf_idf(word, questions, n) 
#all_merged_nonprod

# GGPLOT of non-prod people
tfidf_nonprod_plot <- all_merged_nonprod %>%
    arrange(desc(tf_idf)) %>%
    mutate(word=factor(word, levels=rev(unique(word)))) %>%
    group_by(questions) %>%
    top_n(5) %>%
    ungroup %>%
    ggplot(aes(word, tf_idf, fill=questions))+
    geom_col(show.legend=FALSE)+
    facet_wrap(~questions, ncol=2, scales="free")+
    labs(x=NULL, y="tf-idf")+
    coord_flip()
tfidf_nonprod_plot

# Filter productive
all_merged_prod <- all_merged %>% 
    filter(response == 1)

# TFIDF Creation productive
all_merged_prod <- all_merged_prod %>%
    bind_tf_idf(word, questions, n) 
#all_merged_prod

# GGPLOT of non-prod people
tfidf_prod_plot <- all_merged_prod %>%
    arrange(desc(tf_idf)) %>%
    mutate(word=factor(word, levels=rev(unique(word)))) %>%
    group_by(questions) %>%
    top_n(5) %>%
    ungroup %>%
    ggplot(aes(word, tf_idf, fill=questions))+
    geom_col(show.legend=FALSE)+
    facet_wrap(~questions, ncol=2, scales="free")+
    labs(x=NULL, y="tf-idf")+
    coord_flip()
tfidf_prod_plot

full_tfidf = list(productive = list(all_merged_prod, tfidf_prod_plot),
                   nonproductive = list(all_merged_nonprod, tfidf_nonprod_plot))
#full_tfidf

########## Sentiment #########################
my_sentiment <- my_df %>%
    unnest_tokens(word,value)%>%
    anti_join(stop_words)

# get surprise associated sentiments from the nrc lexicon
nrc_positive <- get_sentiments("nrc") %>%
    filter(sentiment == "positive")

nrc_negative <- get_sentiments("nrc") %>%
    filter(sentiment == "negative")

# Productive Positive Sentiments
pp_struc <- my_df %>%
    filter(response == 1) %>%
    unnest_tokens(word, value) %>%
    inner_join(nrc_positive)%>%
    anti_join(stop_words) %>%
    count(word, sentiment, sort = TRUE)%>%
    ungroup()

wordcloud_pp <- pp_struc %>%
    group_by(sentiment) %>%
    top_n(10) %>%
    ungroup() %>%
    mutate(word=reorder(word, n)) %>%
    ggplot(aes(word, n, fill=sentiment)) +
    geom_col(show.legend = FALSE) +
    facet_wrap(~sentiment, scales = "free_y")+
    labs(y="Productive Positive Sentiments", x=NULL)+
    labs(x=NULL, y="")+
    coord_flip()

# Productive Negative Sentiments
pn_struc <- my_df %>%
    filter(response == 1) %>%
    unnest_tokens(word, value) %>%
    inner_join(nrc_negative)%>%
    anti_join(stop_words) %>%
    count(word, sentiment, sort = TRUE)%>%
    ungroup()

wordcloud_pn <- pn_struc %>%
    group_by(sentiment) %>%
    top_n(10) %>%
    ungroup() %>%
    mutate(word=reorder(word, n)) %>%
    ggplot(aes(word, n, fill=sentiment)) +
    geom_col(show.legend = FALSE) +
    facet_wrap(~sentiment, scales = "free_y")+
    labs(y="Productive Negative Sentiments", x=NULL)+
    labs(x=NULL, y="")+
    coord_flip()

# Non Productive Positive sentiments 
pnp_struc <- my_df %>%
    filter(response == 0) %>%
    unnest_tokens(word, value) %>%
    inner_join(nrc_positive)%>%
    anti_join(stop_words) %>%
    count(word, sentiment, sort = TRUE) %>%
    ungroup()

wordcloud_pnp <- pnp_struc %>%
    group_by(sentiment) %>%
    top_n(10) %>%
    ungroup() %>%
    mutate(word=reorder(word, n)) %>%
    ggplot(aes(word, n, fill=sentiment)) +
    geom_col(show.legend = FALSE) +
    facet_wrap(~sentiment, scales = "free_y")+
    labs(y="Not-Productive Positive Sentiments", x=NULL)+
    labs(x=NULL, y="")+
    coord_flip()

# Non Productive Negative sentiments 
nnp_struc <- my_df %>%
    filter(response == 0) %>%
    unnest_tokens(word, value) %>%
    inner_join(nrc_negative)%>%
    anti_join(stop_words) %>%
    count(word, sentiment, sort = TRUE) %>%
    ungroup()

wordcloud_nnp <- nnp_struc %>%
    group_by(sentiment) %>%
    top_n(10) %>%
    ungroup() %>%
    mutate(word=reorder(word, n)) %>%
    ggplot(aes(word, n, fill=sentiment)) +
    geom_col(show.legend = FALSE) +
    facet_wrap(~sentiment, scales = "free_y")+
    labs(y="Not-Productive Negative Sentiments", x=NULL)+
    labs(x=NULL, y="")+
    coord_flip()


### Naive Bayes 
# Tokenize and remove stopwords
naive_df <- my_df %>% 
    unnest_tokens(word, value) %>% 
    anti_join(stop_words)

# Random the order before put it in the model
set.seed(42)

opinions = Corpus(VectorSource(naive_df$word))

#turn file into regular corpus 
msg.dfm <- dfm(corpus(opinions), tolower = TRUE)	 #generating document 
msg.dfm <- dfm_trim(msg.dfm, min_termfreq = 2, min_docfreq  = 1)
msg.dfm <- dfm_weight(msg.dfm)

#create training & testing set 
msg.dfm.train<-msg.dfm[1:43,] 	#train doc 1-26
msg.dfm.test<-msg.dfm[44:49,]		#test doc 31-34

responsevector <- c(0,1,1,1,1,0,0,0,1,0,1,0,0,1,0,1,0,1,0,1,0,1,1,0,0,1,1,1,0,1,0,0,1,1,1,0,0,1,1,1,1,0,1)
length(responsevector)
#building the Naive Bayes model:
#for train test, assign label: doc 1 = 1 (success), doc 2 = 1 (success), etc for 26 docs
NB_classifier <- textmodel_nb(msg.dfm.train, responsevector)
#NB_classifier
summary(NB_classifier) 	

# predicting the testing data
pred <- predict(NB_classifier, msg.dfm.test)
print(pred)


# Server
server <- function(input, output) {
    
        output$wordCloud <- renderPlot({
            #full_sentiments[[input$selectPlotWordCloud]]
            if (input$selectPlotWordCloud == "ProductivePositive"){
                wordcloud_pp }
            else if(input$selectPlotWordCloud == "ProductiveNegative") {
                wordcloud_pn
            }else if(input$selectPlotWordCloud == "NonProductivePositive") {
                wordcloud_pnp
            }else{
                wordcloud_nnp
            }
        })
        
        output$TFIDF <- renderPlot({
            #full_tfidf[[input$selectPlotTFIDF]][2]
            if (input$selectPlotTFIDF == "Productive"){
                tfidf_prod_plot }
            else{
                tfidf_nonprod_plot
            }
        })
    
        output$bigram <- renderPlot({
            #full_bigram[[input$selectPlotBigram]][2]
            if (input$selectPlotBigram == "Productive"){
                productiveBigram }
            else{
                    nonProductiveBigram
               }
        })
        
        output$bayes <- renderPrint({
            opinions = Corpus(VectorSource(input$bayestext))
            userInputDfm <- dfm(corpus(opinions), tolower = TRUE)
            predBayes <- predict(NB_classifier, userInputDfm, force = TRUE)
            predBayes <- predBayes %>% as.character()
            ifelse(predBayes == '0', 'Non Productive', 'Productive') %>% writeLines()
        })
        
        
}
