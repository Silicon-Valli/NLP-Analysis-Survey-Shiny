#  SUPER BOWL - TEAM10
#########################################################
# Initialization                                        #
#########################################################
library(shinyBS)
library(rintrojs)
library(shinydashboard)
library(shinyWidgets)
questions <- c("1.	Describe SuperBowl to a Non-American.", 
               "2.	Which Team are you supporting? Why?",
               "3.	Which commercials will be aired during the SuperBowl event? Any memorable ones?",
               "4.	What are your expectations of the halftime show? Maybe for next year?",
               "5.	How many beverages will be consumed in the US during the event?",
               "6.	Have you been productive the day after the SuperBowl?")
first <- questions[1] # assigning the first question


# Header code                                            
header <- dashboardHeader(
    title = "SUPERBOWL", titleWidth = 230, 
    dropdownMenu(type="messages", messageItem(from="SuperbowlNFL", message = "Last chance!", href ="https://en.wikipedia.org/wiki/Super_Bowl_LV")),
    dropdownMenu(type="notifications", notificationItem(tex="check out Superbowl", href="https://en.wikipedia.org/wiki/Super_Bowl_LV")),
    dropdownMenu(type="tasks", taskItem(text="Superbowl details", value=20))
)  #Close DashboardHeader


# Sidebar code                                          
sidebar <- dashboardSidebar(
    sidebarMenu(menuItem('Introduction',tabName = 'introduction', icon = icon('question')),
                menuItem("Sentiment", tabName = "sentiment", icon = icon("dashboard")),
                menuItem("Characteristic Words", tabName = "TFIDF", icon = icon("chart-line")),
                menuItem("Network Analysis", tabName = "networkAnalysis", icon = icon("th")),
                menuItem('Naive Bayes Classification', tabName = 'naiveBayesClassification', icon = icon('lightbulb')), 
                #menuItem('Conclusion', tabName = 'conclusion', icon = icon('handshake')),
                tags$head(tags$style(HTML(".skin-blue .main-sidebar {background-color:  grey;}"))) #color
                )
) #Close DashboardSidebar


# Body Code
body <- dashboardBody(
        tags$head(tags$style(HTML(".small-box {width: 300px}div.box-header {text-align: center;}"))),
        tabItems(
        # First tab content    
        tabItem(tabName = "introduction",mainPanel(box(
            title = "Superbowl", width = 15, background = "light-blue",
            "This app is designed to understand behavior of people with Superbowl Even by analyzing
            the answers to questions about different things that may happen during the game.
            "),
            box(width = 15, background = "light-blue",
                "If you're not a football guru, that's ok too. Play along!! "
            )),
            verticalLayout(box('1. Describe SuperBowl to a Non-American.',width = 5, background = "teal"),
                           box('2. Which Team are you supporting? Why?',width = 5, background = "teal"),
                           box('3. Which commercials will be aired during the SuperBowl event?',width = 5, background = "teal"),
                           box('4. What are your expectations of the halftime show? Maybe for next year?',width = 5, background = "teal"),
                           box('5. How many beverages will be consumed in the US during the event?',width = 5, background = "teal"),
                           box('6. Have you been productive the day after the SuperBowl?',width = 5, background = "teal"))),
        
        # Second tab content
        tabItem(tabName = "sentiment",
                h2("Analysis"),
                # Content
                mainPanel(selectInput("selectPlotWordCloud", "Choose Productivity status", 
                                      choices = c("ProductivePositive", "ProductiveNegative","NonProductivePositive","NonProductiveNegative")), 
                          plotOutput("wordCloud"))),
        
        
        # Third Tab Content
        tabItem(tabName = "TFIDF",
                h2("TFIDF Analysis"),
                # Content 
                mainPanel(selectInput("selectPlotTFIDF", "Choose Productivity status", choices = c("Productive", "Not Productive")),
                          plotOutput("TFIDF"))),
        
        # Fourth Tab Content
        tabItem(tabName = "networkAnalysis",
                h2("Network Analysis"),
                mainPanel(selectInput("selectPlotBigram", "Choose Productivity status", choices = c("Productive", "Not Productive")), 
                          plotOutput("bigram"))),
        
        # Fifth Tab Content
        tabItem(tabName = "naiveBayesClassification",
                h2("Naive Bayes Classification"),
                mainPanel(  textInput("bayestext", 
                                      label = h3("Enter the candidate response:"), 
                                      value = "Enter text..."), 
                            valueBox(
                                uiOutput("bayes"), "Model Prediction",
                                href = "https://www.sportingnews.com/us/nfl/news/super-bowl-2021-live-score-chiefs-buccaneers-results-highlights/2bvvgmjbf7i51m41vwyfahjj5"
                            )))
        
        )
)#close DashboardBody

# Main code
ui <- dashboardPage(header, sidebar, body)